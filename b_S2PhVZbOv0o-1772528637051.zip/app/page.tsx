"use client";

import { useEffect, useRef, useState, useCallback } from "react";

/* ─────────────── TYPES ─────────────── */
type ScenarioId = "disaster" | "patrol" | "fire" | "security";
type TechId = "flight" | "vision" | "route" | "comms" | "payload";

/* ─────────────── HOOK ─────────────── */
function useInView(ref: React.RefObject<Element | null>, threshold = 0.12) {
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return inView;
}

/* ─────────────── DATA ─────────────── */
const DEMAND_BLOCKS = [
  { category: "低空经济", items: ["空域精细化管理", "低空基础设施巡检", "物流通道监控", "城市空中交通"] },
  { category: "智慧城市治理", items: ["城市基础设施监测", "违规行为识别", "环境污染溯源", "交通态势感知"] },
  { category: "应急响应现代化", items: ["灾情快速评估", "搜救目标定位", "危险区域探测", "现场实时回传"] },
  { category: "公共安全数字化", items: ["大型活动安保", "边界防控预警", "危化品泄漏监测", "群体事件研判"] },
];

const PAIN_POINTS = [
  { id: "01", title: "传统巡检响应链断裂", desc: "人工巡检依赖地面人员，视野受限、信息滞后，遇突发事件无法及时响应，平均处置时延超 45 分钟。", metric: "响应时延 > 45min", color: "#ef4444" },
  { id: "02", title: "多源数据孤岛严重", desc: "传感器、视频、气象等数据分散存储，缺乏统一融合决策平台，协同指挥效率低下。", metric: "数据融合率 < 30%", color: "#f59e0b" },
  { id: "03", title: "复杂环境感知能力不足", desc: "现有无人机缺乏智能避障与自主决策能力，在夜间、恶劣天气或密集障碍场景中作业安全性差。", metric: "复杂场景覆盖率 < 40%", color: "#f59e0b" },
  { id: "04", title: "人力成本居高不下", desc: "大范围持续巡检需大量一线人员，危险场所作业存在安全风险，人力成本占总运营成本 65% 以上。", metric: "人力占比 > 65%", color: "#00b4d8" },
];

const ARCH_NODES = [
  { id: "airborne", label: "空基平台", sub: "Airborne Platform", desc: "多旋翼/固定翼集群，集成多光谱/热成像传感器阵列", color: "#00b4d8" },
  { id: "sensing", label: "感知层", sub: "Sensing Layer", desc: "可见光、红外、气体检测、LiDAR多源融合感知", color: "#0077b6" },
  { id: "transmission", label: "数据传输", sub: "Data Transmission", desc: "5G/专网加密链路，支持1080P实时视频双工传输", color: "#48cae4" },
  { id: "ai", label: "AI决策引擎", sub: "AI Decision Engine", desc: "边缘推理+云端协同，目标检测/行为识别/风险评估", color: "#00b4d8", highlight: true },
  { id: "command", label: "地面指挥中心", sub: "Ground Command", desc: "态势感知大屏、任务调度、跨部门协同指挥", color: "#0077b6" },
  { id: "execution", label: "反馈执行", sub: "Feedback Execution", desc: "指令下发、任务核验、处置结果闭环上报", color: "#22c55e" },
];

const TECH_MODULES: Array<{
  id: TechId; index: string; title: string; sub: string; color: string;
  principle: string; functions: string[]; output: string;
  metrics: Array<{ label: string; value: number; unit: string }>;
}> = [
  {
    id: "flight", index: "T-01", title: "自主飞行控制", sub: "Autonomous Flight Control", color: "#00b4d8",
    principle: "基于状态机 + 强化学习的双模态控制律，融合IMU/GPS/视觉里程计实现厘米级定位",
    functions: ["自主起降", "动态避障", "编队协同", "断链返航"],
    output: "单机误差 < 10cm，集群编队间距精度 ± 0.5m",
    metrics: [{ label: "定位精度", value: 96, unit: "cm级" }, { label: "避障成功率", value: 99, unit: "%" }],
  },
  {
    id: "vision", index: "T-02", title: "AI视觉识别", sub: "AI Visual Recognition", color: "#0077b6",
    principle: "YOLOv8 + 轻量化Transformer双网络架构，边端推理加速，支持小目标与遮挡场景",
    functions: ["目标检测与跟踪", "异常行为识别", "设施缺陷检测", "人员计数"],
    output: "识别准确率 99.6%，推理帧率 > 30FPS（边端）",
    metrics: [{ label: "识别准确率", value: 99, unit: "%" }, { label: "推理速度", value: 85, unit: "FPS" }],
  },
  {
    id: "route", index: "T-03", title: "智能路径规划", sub: "Intelligent Route Planning", color: "#48cae4",
    principle: "改进A* + 动态势场算法，结合禁飞区数据库与实时气象信息进行全局-局部双层规划",
    functions: ["最优航线生成", "动态绕障重规划", "多机任务分配", "覆盖率最大化"],
    output: "覆盖效率提升 40%，路径冗余度降低 28%",
    metrics: [{ label: "覆盖效率提升", value: 78, unit: "%" }, { label: "规划时延", value: 62, unit: "ms" }],
  },
  {
    id: "comms", index: "T-04", title: "实时通信系统", sub: "Real-Time Communication", color: "#0077b6",
    principle: "5G + 专用数据链双冗余通信架构，AES-256加密，支持Mesh组网动态中继",
    functions: ["高清视频实时回传", "指令低延下发", "多机状态同步", "断链自愈"],
    output: "端到端时延 < 80ms，链路可用率 99.98%",
    metrics: [{ label: "链路可用率", value: 99, unit: "%" }, { label: "端到端时延", value: 72, unit: "ms" }],
  },
  {
    id: "payload", index: "T-05", title: "模块化载荷集成", sub: "Modular Payload Integration", color: "#00b4d8",
    principle: "标准化快插载荷接口（机械+电气+数据三合一），即换即用，支持热插拔",
    functions: ["可见光摄像", "红外热像", "气体检测", "喊话广播"],
    output: "载荷切换时间 < 5min，兼容 12 种标准载荷模块",
    metrics: [{ label: "兼容载荷数", value: 80, unit: "种" }, { label: "切换效率", value: 90, unit: "%" }],
  },
];

const SCENARIOS: Array<{
  id: ScenarioId; title: string; sub: string; color: string;
  steps: Array<{ label: string; desc: string; data: string }>;
}> = [
  {
    id: "disaster", title: "灾情救援", sub: "DISASTER RESCUE", color: "#ef4444",
    steps: [
      { label: "无人机起飞", desc: "集群编队完成自检，快速起飞进入任务区域，建立空中观测网格", data: "起飞高度 120m · 编队数量 6架" },
      { label: "目标侦测", desc: "AI视觉系统扫描受灾区域，红外热成像识别被困人员体征", data: "识别目标 14个 · 置信度 97.3%" },
      { label: "AI风险评估", desc: "实时分析建筑结构稳定性、道路通达性、次生灾害风险指数", data: "风险等级 HIGH · 禁入区 3处" },
      { label: "指挥决策", desc: "地面指挥中心下达救援指令，协调救援资源最优分配", data: "调配人员 32人 · 车辆 8辆" },
      { label: "任务完成", desc: "被困人员全部转移，灾情数据上报完毕，无人机返航", data: "完成率 100% · 耗时 18min" },
    ],
  },
  {
    id: "patrol", title: "城市巡检", sub: "URBAN PATROL", color: "#00b4d8",
    steps: [
      { label: "航线规划", desc: "AI路径规划引擎生成覆盖率最优的巡检路径，规避禁飞区", data: "覆盖面积 12.4km² · 规划时延 0.8s" },
      { label: "高空扫描", desc: "多光谱相机扫描城市基础设施，记录设施健康状态数据", data: "扫描分辨率 2cm/px · 帧率 60FPS" },
      { label: "异常识别", desc: "YOLOv8模型实时检测管道破损、路面塌陷、违规建设", data: "发现异常 7处 · 误报率 0.4%" },
      { label: "数据上报", desc: "异常坐标、图像证据自动打包上报至城市管理平台", data: "上报延时 < 3s · 数据包 486MB" },
      { label: "归档完成", desc: "巡检报告自动生成，数据归档，触发相关部门处置流程", data: "报告生成 2.1s · 处置工单 7单" },
    ],
  },
  {
    id: "fire", title: "火灾监控", sub: "FIRE MONITORING", color: "#f59e0b",
    steps: [
      { label: "热点预警", desc: "热成像传感器实时监测区域温度异常，触发火灾预警阈值", data: "温度异常 +380°C · 预警时延 1.2s" },
      { label: "火情确认", desc: "可见光+红外双模态融合确认火情，排除干扰源误报", data: "确认率 99.1% · 确认耗时 3.4s" },
      { label: "蔓延预测", desc: "结合风速风向、植被密度，AI预测火势蔓延方向与范围", data: "预测精度 91.5% · 预警范围 2.3km²" },
      { label: "资源调度", desc: "自动推送消防力量调配建议，标注最优进场路线", data: "调派车辆 12辆 · 到达预计 7min" },
      { label: "处置完毕", desc: "火情扑灭确认，空中持续监测30分钟防止复燃", data: "监测时长 30min · 复燃概率 0%" },
    ],
  },
  {
    id: "security", title: "安保防控", sub: "SECURITY CONTROL", color: "#a855f7",
    steps: [
      { label: "区域布控", desc: "在指定安保范围内建立无人机空中巡逻网格，全域覆盖", data: "布控面积 8.6km² · 盲区率 0.3%" },
      { label: "人群分析", desc: "AI人流计数与密度分析，实时监测异常聚集与可疑行为", data: "人流监测 23,400人 · 分析帧率 25FPS" },
      { label: "事件研判", desc: "多维特征融合判断异常事件级别，生成处置建议", data: "事件等级 B级 · 研判耗时 2.1s" },
      { label: "力量部署", desc: "引导地面安保快速响应，提供实时态势图与路径引导", data: "响应人员 16人 · 到位 4.3min" },
      { label: "事件结案", desc: "事件记录归档，全程视频证据链完整保存至安全服务器", data: "证据完整率 100% · 归档耗时 0.8s" },
    ],
  },
];

/* ─────────────── NAV ─────────────── */
function SiteNav() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <header
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{
        background: scrolled ? "rgba(4,13,26,0.97)" : "rgba(4,13,26,0.75)",
        borderBottom: `1px solid ${scrolled ? "rgba(0,180,216,0.25)" : "rgba(0,180,216,0.08)"}`,
        backdropFilter: "blur(12px)",
      }}
    >
      <div className="max-w-7xl mx-auto px-6 h-14 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <svg viewBox="0 0 28 28" fill="none" className="w-7 h-7 flex-shrink-0">
            <polygon points="14,2 26,8 26,20 14,26 2,20 2,8" stroke="rgba(0,180,216,0.8)" strokeWidth="1.2" fill="none" />
            <polygon points="14,7 21,11 21,19 14,23 7,19 7,11" stroke="rgba(0,180,216,0.4)" strokeWidth="0.8" fill="rgba(0,180,216,0.06)" />
            <circle cx="14" cy="14" r="2.5" fill="rgba(0,180,216,0.9)" />
          </svg>
          <div>
            <div className="text-xs font-bold tracking-[0.2em]" style={{ fontFamily: "'Orbitron',monospace", color: "#00b4d8" }}>空基尖兵</div>
            <div className="text-[9px] tracking-[0.15em]" style={{ color: "rgba(0,180,216,0.45)" }}>AERIAL VANGUARD SYSTEM</div>
          </div>
        </div>
        <nav className="hidden md:flex items-center gap-1">
          {[["战略定位","#strategy"],["问题分析","#problem"],["系统架构","#architecture"],["核心技术","#technology"],["任务模拟","#simulation"]].map(([label,href]) => (
            <a key={href} href={href} className="px-4 py-1.5 text-[11px] tracking-widest transition-colors duration-200"
              style={{ fontFamily: "'Share Tech Mono',monospace", color: "rgba(106,172,232,0.65)" }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.color = "#00b4d8"; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.color = "rgba(106,172,232,0.65)"; }}
            >{label}</a>
          ))}
        </nav>
        <div className="hidden md:flex items-center gap-2 px-3 py-1" style={{ border: "1px solid rgba(0,180,216,0.2)", background: "rgba(0,180,216,0.04)" }}>
          <span className="w-1.5 h-1.5 rounded-full" style={{ background: "#22c55e", boxShadow: "0 0 6px #22c55e" }} />
          <span className="text-[9px] tracking-[0.2em]" style={{ color: "#22c55e" }}>SYSTEM ONLINE</span>
        </div>
      </div>
    </header>
  );
}

/* ─────────────── HERO ─────────────── */
function HeroSection() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let raf: number;
    let t = 0;
    const resize = () => { canvas.width = canvas.offsetWidth; canvas.height = canvas.offsetHeight; };
    resize();
    window.addEventListener("resize", resize);
    const nodes = Array.from({ length: 6 }, (_, i) => ({
      x: 0.15 + (i % 3) * 0.28, y: 0.25 + Math.floor(i / 3) * 0.45, phase: (i / 6) * Math.PI * 2,
    }));
    const draw = () => {
      const w = canvas.width; const h = canvas.height;
      ctx.clearRect(0, 0, w, h);
      ctx.strokeStyle = "rgba(0,180,216,0.06)"; ctx.lineWidth = 0.5;
      for (let x = 0; x < w; x += 40) { ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,h); ctx.stroke(); }
      for (let y = 0; y < h; y += 40) { ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(w,y); ctx.stroke(); }
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const a = nodes[i]; const b = nodes[j];
          const ax = a.x*w + Math.sin(t*0.4+a.phase)*18; const ay = a.y*h + Math.cos(t*0.3+a.phase)*12;
          const bx = b.x*w + Math.sin(t*0.4+b.phase)*18; const by = b.y*h + Math.cos(t*0.3+b.phase)*12;
          const dist = Math.hypot(ax-bx, ay-by);
          if (dist < w*0.38) {
            ctx.strokeStyle = `rgba(0,180,216,${(1-dist/(w*0.38))*0.22})`; ctx.lineWidth = 0.8;
            ctx.beginPath(); ctx.moveTo(ax,ay); ctx.lineTo(bx,by); ctx.stroke();
          }
        }
      }
      nodes.forEach(n => {
        const x = n.x*w + Math.sin(t*0.4+n.phase)*18; const y = n.y*h + Math.cos(t*0.3+n.phase)*12;
        const p = 0.5 + 0.5*Math.sin(t*1.2+n.phase);
        ctx.beginPath(); ctx.arc(x,y,14+p*6,0,Math.PI*2); ctx.strokeStyle=`rgba(0,180,216,${0.08+p*0.12})`; ctx.lineWidth=1; ctx.stroke();
        ctx.beginPath(); ctx.arc(x,y,7,0,Math.PI*2); ctx.strokeStyle="rgba(0,180,216,0.4)"; ctx.lineWidth=1; ctx.stroke();
        ctx.beginPath(); ctx.arc(x,y,3,0,Math.PI*2); ctx.fillStyle="#00b4d8"; ctx.shadowBlur=10; ctx.shadowColor="#00b4d8"; ctx.fill(); ctx.shadowBlur=0;
      });
      t += 0.012; raf = requestAnimationFrame(draw);
    };
    draw();
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); };
  }, []);

  return (
    <section className="relative min-h-screen flex flex-col justify-center overflow-hidden" style={{ background:"#040d1a", backgroundImage:"linear-gradient(rgba(0,180,216,0.05) 1px,transparent 1px),linear-gradient(90deg,rgba(0,180,216,0.05) 1px,transparent 1px)", backgroundSize:"40px 40px" }}>
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />
      <div className="absolute inset-0 pointer-events-none" style={{ background:"radial-gradient(ellipse 70% 60% at 50% 45%, rgba(0,119,182,0.12) 0%, transparent 70%)" }} />
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background:"rgba(0,180,216,0.4)" }} />
      <div className="relative z-10 max-w-7xl mx-auto px-6 pt-24 pb-16">
        <div className="inline-flex items-center gap-3 mb-8 px-4 py-1.5" style={{ border:"1px solid rgba(0,180,216,0.25)", background:"rgba(0,180,216,0.05)" }}>
          <span className="w-1.5 h-1.5 rounded-full" style={{ background:"#00b4d8", boxShadow:"0 0 6px #00b4d8" }} />
          <span className="text-[10px] tracking-[0.3em]" style={{ color:"rgba(0,180,216,0.7)", fontFamily:"'Orbitron',monospace" }}>国家创新竞赛 · 参赛项目展示</span>
        </div>
        <div className="mb-6">
          <h1 className="text-5xl md:text-7xl font-bold leading-none tracking-tight mb-3" style={{ fontFamily:"'Orbitron',monospace", color:"#cce4f7" }}>空基尖兵</h1>
          <div className="text-xl md:text-2xl tracking-widest font-light" style={{ color:"#00b4d8", fontFamily:"'Orbitron',monospace" }}>智能空基无人机协同体系</div>
        </div>
        <div className="flex items-center gap-4 mb-8">
          <div className="flex-1 h-px" style={{ background:"rgba(0,180,216,0.2)" }} />
          <span className="text-[9px] tracking-[0.35em]" style={{ color:"rgba(0,180,216,0.4)" }}>INTELLIGENT AERIAL COORDINATION PLATFORM</span>
          <div className="flex-1 h-px" style={{ background:"rgba(0,180,216,0.2)" }} />
        </div>
        <p className="max-w-2xl text-base leading-relaxed mb-12" style={{ color:"#5a90b8" }}>
          面向低空经济、智慧城市治理与应急响应现代化，构建以无人机集群为核心载体，融合AI决策引擎与地面指挥中心的闭环协同巡检体系，实现复杂场景下的全天候精准感知与快速响应。
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {[["99.6%","目标识别准确率"],["< 3s","决策响应时延"],["120km","单次巡查覆盖范围"],["7×24h","全天候持续作业"]].map(([v,l]) => (
            <div key={l} className="p-4" style={{ border:"1px solid rgba(0,180,216,0.15)", background:"rgba(0,180,216,0.04)" }}>
              <div className="text-2xl font-bold mb-1" style={{ fontFamily:"'Orbitron',monospace", color:"#00b4d8" }}>{v}</div>
              <div className="text-[10px] tracking-wider" style={{ color:"#3d6e92" }}>{l}</div>
            </div>
          ))}
        </div>
        <div className="flex flex-wrap gap-4">
          <a href="#architecture" className="px-8 py-3 text-xs tracking-[0.2em] font-bold transition-all duration-200" style={{ fontFamily:"'Orbitron',monospace", background:"#00b4d8", color:"#040d1a" }}
            onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.background="#48cae4";}} onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background="#00b4d8";}}>查看系统架构</a>
          <a href="#simulation" className="px-8 py-3 text-xs tracking-[0.2em] transition-all duration-200" style={{ fontFamily:"'Orbitron',monospace", border:"1px solid rgba(0,180,216,0.4)", color:"#00b4d8" }}
            onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.background="rgba(0,180,216,0.08)";}} onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background="transparent";}}>进入任务模拟</a>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-24 pointer-events-none" style={{ background:"linear-gradient(to bottom, transparent, #040d1a)" }} />
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
        <div className="text-[9px] tracking-[0.3em]" style={{ color:"rgba(0,180,216,0.3)" }}>SCROLL</div>
        <div className="w-px h-8" style={{ background:"linear-gradient(to bottom, rgba(0,180,216,0.4), transparent)" }} />
      </div>
    </section>
  );
}

/* ─────────────── STRATEGY ─────────────── */
function StrategySection() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref);
  return (
    <section id="strategy" className="py-24" style={{ background:"#040d1a", borderTop:"1px solid rgba(0,180,216,0.1)" }}>
      <div className="max-w-7xl mx-auto px-6" ref={ref}>
        <div className={`mb-16 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <div className="text-[9px] tracking-[0.4em] mb-3" style={{ color:"rgba(0,180,216,0.5)", fontFamily:"'Orbitron',monospace" }}>LAYER 01 · STRATEGIC POSITIONING</div>
          <h2 className="text-3xl font-bold mb-3" style={{ fontFamily:"'Orbitron',monospace", color:"#cce4f7" }}>国家战略需求对齐</h2>
          <p className="text-sm" style={{ color:"#3d6e92" }}>本系统紧扣国家"十四五"数字经济与低空经济发展战略，以四大核心领域为应用支点</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {DEMAND_BLOCKS.map((block, bi) => (
            <div key={bi} className={`p-5 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`} style={{ transitionDelay:`${bi*0.1}s`, border:"1px solid rgba(0,180,216,0.15)", background:"rgba(0,180,216,0.03)" }}>
              <div className="flex items-center gap-2 mb-4 pb-3" style={{ borderBottom:"1px solid rgba(0,180,216,0.15)" }}>
                <div className="w-1 h-5 flex-shrink-0" style={{ background:"#00b4d8" }} />
                <span className="text-xs font-bold tracking-wider" style={{ color:"#00b4d8", fontFamily:"'Orbitron',monospace" }}>{block.category}</span>
              </div>
              <div className="flex flex-col gap-2">
                {block.items.map((item, ii) => (
                  <div key={ii} className="flex items-center gap-2 py-1.5 px-2" style={{ background:"rgba(0,180,216,0.05)", border:"1px solid rgba(0,180,216,0.08)" }}>
                    <div className="w-1 h-1 rounded-full flex-shrink-0" style={{ background:"rgba(0,180,216,0.6)" }} />
                    <span className="text-[11px]" style={{ color:"#5a90b8" }}>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─────────────── PROBLEM ─────────────── */
function ProblemSection() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref);
  return (
    <section id="problem" className="py-24" style={{ background:"#040d1a", borderTop:"1px solid rgba(0,180,216,0.1)", backgroundImage:"linear-gradient(rgba(0,180,216,0.04) 1px,transparent 1px),linear-gradient(90deg,rgba(0,180,216,0.04) 1px,transparent 1px)", backgroundSize:"20px 20px" }}>
      <div className="max-w-7xl mx-auto px-6" ref={ref}>
        <div className={`mb-16 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <div className="text-[9px] tracking-[0.4em] mb-3" style={{ color:"rgba(0,180,216,0.5)", fontFamily:"'Orbitron',monospace" }}>LAYER 01 · PROBLEM ANALYSIS</div>
          <h2 className="text-3xl font-bold mb-3" style={{ fontFamily:"'Orbitron',monospace", color:"#cce4f7" }}>传统体系痛点解析</h2>
          <p className="text-sm" style={{ color:"#3d6e92" }}>现有应急巡检响应链在以下四个维度存在系统性缺陷</p>
        </div>
        {/* Broken chain */}
        <div className={`mb-14 p-6 transition-all duration-700 delay-200 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`} style={{ border:"1px solid rgba(0,180,216,0.12)", background:"rgba(6,18,31,0.6)" }}>
          <div className="text-[9px] tracking-[0.3em] mb-5" style={{ color:"rgba(0,180,216,0.4)" }}>传统应急响应链路 · BROKEN CHAIN</div>
          <div className="flex flex-wrap items-center gap-2">
            {["人工巡检","电话上报","领导审批","调派人员","抵达现场","处置作业"].map((step, i) => (
              <div key={i} className="flex items-center gap-2">
                <div className="relative px-3 py-2 text-[11px]" style={{ border:`1px solid ${i===2||i===4?"rgba(239,68,68,0.5)":"rgba(0,180,216,0.2)"}`, background:`${i===2||i===4?"rgba(239,68,68,0.06)":"rgba(0,180,216,0.04)"}`, color:i===2||i===4?"#ef4444":"#5a90b8" }}>
                  {(i===2||i===4) && <span className="absolute -top-3 left-1/2 -translate-x-1/2 text-[8px]" style={{ color:"#ef4444" }}>瓶颈</span>}
                  {step}
                </div>
                {i<5 && <span style={{ color:i===2||i===4?"rgba(239,68,68,0.6)":"rgba(0,180,216,0.4)" }}>→</span>}
              </div>
            ))}
            <div className="ml-2 px-3 py-2 text-[10px] tracking-wider" style={{ border:"1px solid rgba(239,68,68,0.4)", background:"rgba(239,68,68,0.05)", color:"#ef4444" }}>平均延误 45min+</div>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {PAIN_POINTS.map((p, i) => (
            <div key={p.id} className={`p-5 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`} style={{ transitionDelay:`${i*0.1+0.3}s`, border:`1px solid ${p.color}22`, background:"rgba(6,18,31,0.8)" }}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold" style={{ fontFamily:"'Orbitron',monospace", color:p.color, opacity:0.6 }}>{p.id}</span>
                  <span className="text-xs font-bold" style={{ color:"#cce4f7" }}>{p.title}</span>
                </div>
                <span className="text-[9px] px-2 py-0.5 tracking-wider flex-shrink-0" style={{ border:`1px solid ${p.color}44`, color:p.color, background:`${p.color}0a`, fontFamily:"'Orbitron',monospace" }}>{p.metric}</span>
              </div>
              <p className="text-[11px] leading-relaxed" style={{ color:"#3d6e92" }}>{p.desc}</p>
              <div className="mt-4 h-px" style={{ background:`linear-gradient(to right, ${p.color}44, transparent)` }} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─────────────── ARCHITECTURE ─────────────── */
function ArchitectureSection() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref);
  const [activeNode, setActiveNode] = useState<string | null>(null);
  return (
    <section id="architecture" className="py-24" style={{ background:"#040d1a", borderTop:"1px solid rgba(0,180,216,0.1)" }}>
      <div className="max-w-7xl mx-auto px-6" ref={ref}>
        <div className={`mb-16 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <div className="text-[9px] tracking-[0.4em] mb-3" style={{ color:"rgba(0,180,216,0.5)", fontFamily:"'Orbitron',monospace" }}>LAYER 01 · CORE SYSTEM ARCHITECTURE</div>
          <h2 className="text-3xl font-bold mb-3" style={{ fontFamily:"'Orbitron',monospace", color:"#cce4f7" }}>全系统架构图</h2>
          <p className="text-sm" style={{ color:"#3d6e92" }}>六层闭环体系架构——从前端空基感知到后端决策执行，形成自主运转的智能闭环</p>
        </div>
        <div className={`p-8 mb-8 relative transition-all duration-700 delay-200 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`} style={{ border:"1px solid rgba(0,180,216,0.15)", background:"rgba(6,18,31,0.8)" }}>
          {["top-0 left-0 border-t border-l","top-0 right-0 border-t border-r","bottom-0 left-0 border-b border-l","bottom-0 right-0 border-b border-r"].map((cls,i)=>(
            <div key={i} className={`absolute w-4 h-4 ${cls}`} style={{ borderColor:"rgba(0,180,216,0.5)" }} />
          ))}
          <div className="text-[9px] tracking-[0.35em] mb-8 text-center" style={{ color:"rgba(0,180,216,0.35)" }}>CLOSED-LOOP INTELLIGENT COORDINATION SYSTEM</div>
          <div className="flex flex-wrap items-stretch justify-center gap-0">
            {ARCH_NODES.map((node, i) => (
              <div key={node.id} className="flex items-center">
                <div className="flex flex-col items-center cursor-pointer transition-all duration-300"
                  style={{ width:"130px", padding:"16px 12px", border:`1px solid ${activeNode===node.id?node.color+"80":node.color+"22"}`, background:activeNode===node.id?`${node.color}10`:node.highlight?`${node.color}06`:"rgba(0,0,0,0.2)", boxShadow:activeNode===node.id?`0 0 20px ${node.color}30`:"none", transform:activeNode===node.id?"translateY(-4px)":"none" }}
                  onMouseEnter={()=>setActiveNode(node.id)} onMouseLeave={()=>setActiveNode(null)}>
                  <div className="text-xs font-bold text-center mb-1" style={{ color:activeNode===node.id?node.color:"#cce4f7", fontFamily:"'Orbitron',monospace" }}>{node.label}</div>
                  <div className="text-[8px] text-center tracking-wider" style={{ color:"rgba(0,180,216,0.4)" }}>{node.sub}</div>
                  {node.highlight && <div className="mt-2 px-2 py-0.5 text-[7px] tracking-wider" style={{ border:"1px solid rgba(0,180,216,0.4)", color:"#00b4d8", background:"rgba(0,180,216,0.06)" }}>CORE</div>}
                </div>
                {i < ARCH_NODES.length - 1 && (
                  <div className="flex flex-col items-center" style={{ width:"32px", flexShrink:0 }}>
                    <div className="w-full h-px" style={{ background:"rgba(0,180,216,0.25)" }} />
                    <div className="text-[10px]" style={{ color:"rgba(0,180,216,0.5)", marginTop:"-6px" }}>▶</div>
                  </div>
                )}
              </div>
            ))}
          </div>
          <div className="mt-8 flex justify-center">
            <div className="flex items-center gap-6 px-6 py-3 text-[10px]" style={{ border:"1px solid rgba(34,197,94,0.2)", background:"rgba(34,197,94,0.04)", color:"rgba(34,197,94,0.7)" }}>
              <span className="text-[8px] tracking-[0.3em]">CLOSED-LOOP FEEDBACK</span>
              <div className="h-px" style={{ background:"linear-gradient(to right,rgba(34,197,94,0.4),rgba(0,180,216,0.4))", width:"80px" }} />
              <span className="text-[8px] tracking-[0.3em]">闭环自优化迭代</span>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {ARCH_NODES.map((node, i) => (
            <div key={node.id} className={`p-3 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`} style={{ transitionDelay:`${i*0.08+0.4}s`, border:`1px solid ${node.color}18`, background:"rgba(6,18,31,0.5)" }}>
              <div className="text-[9px] font-bold mb-2" style={{ color:node.color, fontFamily:"'Orbitron',monospace" }}>{node.label}</div>
              <p className="text-[10px] leading-relaxed" style={{ color:"#3d6e92" }}>{node.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─────────────── TECHNOLOGY ─────────────── */
function ProgressBar({ value, color }: { value: number; color: string }) {
  const [width, setWidth] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, 0.5);
  useEffect(() => {
    if (inView) { const t = setTimeout(() => setWidth(value), 200); return () => clearTimeout(t); }
  }, [inView, value]);
  return (
    <div ref={ref} className="h-1 w-full" style={{ background:"rgba(0,0,0,0.4)" }}>
      <div className="h-full transition-all duration-1000 ease-out" style={{ width:`${width}%`, background:color }} />
    </div>
  );
}

function TechnologySection() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref);
  const [activeTab, setActiveTab] = useState<TechId>("flight");
  const mod = TECH_MODULES.find(m => m.id === activeTab) ?? TECH_MODULES[0];
  return (
    <section id="technology" className="py-24" style={{ background:"#040d1a", borderTop:"1px solid rgba(0,180,216,0.1)", backgroundImage:"linear-gradient(rgba(0,180,216,0.04) 1px,transparent 1px),linear-gradient(90deg,rgba(0,180,216,0.04) 1px,transparent 1px)", backgroundSize:"20px 20px" }}>
      <div className="max-w-7xl mx-auto px-6" ref={ref}>
        <div className={`mb-16 transition-all duration-700 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          <div className="text-[9px] tracking-[0.4em] mb-3" style={{ color:"rgba(0,180,216,0.5)", fontFamily:"'Orbitron',monospace" }}>LAYER 01 · CORE TECHNOLOGIES</div>
          <h2 className="text-3xl font-bold mb-3" style={{ fontFamily:"'Orbitron',monospace", color:"#cce4f7" }}>核心技术模块</h2>
          <p className="text-sm" style={{ color:"#3d6e92" }}>五大核心技术体系，每一模块均完整呈现：原理 → 功能 → 实测产出</p>
        </div>
        <div className={`flex flex-wrap gap-1 mb-6 transition-all duration-700 delay-100 ${inView ? "opacity-100" : "opacity-0"}`} style={{ borderBottom:"1px solid rgba(0,180,216,0.12)" }}>
          {TECH_MODULES.map(m => (
            <button key={m.id} onClick={() => setActiveTab(m.id)} className="flex items-center gap-2 px-4 py-2.5 text-[10px] tracking-wider transition-all duration-200" style={{ fontFamily:"'Orbitron',monospace", color:activeTab===m.id?m.color:"#3d6e92", background:activeTab===m.id?`${m.color}0d`:"transparent", borderBottom:activeTab===m.id?`2px solid ${m.color}`:"2px solid transparent", marginBottom:"-1px" }}>
              <span className="text-[8px]" style={{ color:activeTab===m.id?m.color:"#3d6e92", opacity:0.7 }}>{m.index}</span>{m.title}
            </button>
          ))}
        </div>
        <div className={`grid grid-cols-1 lg:grid-cols-3 gap-4 mb-8 transition-all duration-700 delay-200 ${inView ? "opacity-100" : "opacity-0"}`}>
          {[["PRINCIPLE · 原理", mod.principle, null],["FUNCTION · 功能", null, mod.functions],["OUTPUT · 产出", mod.output, null]].map(([label,text,items],ci) => (
            <div key={ci} className="p-5" style={{ border:`1px solid ${mod.color}22`, background:"rgba(6,18,31,0.8)" }}>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-px h-4" style={{ background:mod.color }} />
                <span className="text-[9px] tracking-[0.3em]" style={{ color:mod.color, fontFamily:"'Orbitron',monospace" }}>{label as string}</span>
              </div>
              {text && <p className="text-[12px] leading-relaxed" style={{ color:"#5a90b8" }}>{text as string}</p>}
              {items && (
                <div className="flex flex-col gap-2">
                  {(items as string[]).map((f,ii) => (
                    <div key={ii} className="flex items-center gap-2">
                      <div className="w-1 h-1 rounded-full flex-shrink-0" style={{ background:mod.color }} />
                      <span className="text-[11px]" style={{ color:"#5a90b8" }}>{f}</span>
                    </div>
                  ))}
                </div>
              )}
              {ci===2 && (
                <div className="mt-5 flex flex-col gap-3">
                  {mod.metrics.map((metric,mi) => (
                    <div key={mi}>
                      <div className="flex justify-between items-center mb-1.5">
                        <span className="text-[10px]" style={{ color:"#3d6e92" }}>{metric.label}</span>
                        <span className="text-[10px] font-bold" style={{ color:mod.color, fontFamily:"'Orbitron',monospace" }}>{metric.value}<span className="text-[8px] ml-0.5" style={{ color:"rgba(0,180,216,0.5)" }}>{metric.unit}</span></span>
                      </div>
                      <ProgressBar value={metric.value} color={mod.color} />
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          {TECH_MODULES.map((m,i) => (
            <button key={m.id} onClick={() => setActiveTab(m.id)} className={`text-left p-4 transition-all duration-200 ${inView ? "opacity-100" : "opacity-0"}`} style={{ transitionDelay:`${i*0.08+0.3}s`, border:`1px solid ${activeTab===m.id?m.color+"50":m.color+"18"}`, background:activeTab===m.id?`${m.color}08`:"rgba(6,18,31,0.5)" }}>
              <div className="text-[8px] mb-1 tracking-wider" style={{ color:`${m.color}70`, fontFamily:"'Orbitron',monospace" }}>{m.index}</div>
              <div className="text-[11px] font-bold mb-1" style={{ color:activeTab===m.id?m.color:"#cce4f7" }}>{m.title}</div>
              <div className="text-[9px]" style={{ color:"#3d6e92" }}>{m.sub}</div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─────────────── SIMULATION ─────────────── */
function SimulationSection() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref);
  const [selected, setSelected] = useState<ScenarioId>("disaster");
  const [running, setRunning] = useState(false);
  const [currentStep, setCurrentStep] = useState(-1);
  const [logs, setLogs] = useState<Array<{ time: string; text: string; color: string }>>([]);
  const [confidence, setConfidence] = useState("--");
  const timersRef = useRef<ReturnType<typeof setTimeout>[]>([]);
  const scenario = SCENARIOS.find(s => s.id === selected)!;

  const clearTimers = () => { timersRef.current.forEach(clearTimeout); timersRef.current = []; };

  const addLog = useCallback((text: string, color: string) => {
    setLogs(prev => [{ time: typeof window !== "undefined" ? new Date().toLocaleTimeString("zh-CN",{hour12:false}) : "--:--:--", text, color }, ...prev].slice(0, 30));
  }, []);

  const runSimulation = useCallback(() => {
    if (running) return;
    clearTimers();
    setRunning(true); setCurrentStep(-1); setLogs([]); setConfidence("--");
    addLog(`[INIT] 任务场景加载：${scenario.title}`, scenario.color);
    scenario.steps.forEach((step, i) => {
      const t = setTimeout(() => {
        setCurrentStep(i);
        setConfidence(`${(94 + Math.random() * 5).toFixed(1)}%`);
        addLog(`[STEP ${i+1}] ${step.label} — ${step.data}`, i===scenario.steps.length-1?"#22c55e":scenario.color);
      }, i * 1800 + 600);
      timersRef.current.push(t);
    });
    const done = setTimeout(() => { setRunning(false); addLog("[COMPLETE] 任务模拟结束，数据已归档","#22c55e"); }, scenario.steps.length*1800+800);
    timersRef.current.push(done);
  }, [running, scenario, addLog]);

  useEffect(() => () => clearTimers(), []);

  const handleSelect = (id: ScenarioId) => { if (running) return; setSelected(id); setCurrentStep(-1); setLogs([]); };
  const progress = currentStep < 0 ? 0 : Math.round(((currentStep+1)/scenario.steps.length)*100);

  return (
    <section id="simulation" className="py-24" style={{ background:"#040d1a", borderTop:"1px solid rgba(0,180,216,0.1)" }}>
      <div className="max-w-7xl mx-auto px-6" ref={ref}>
        <div className={`mb-16 transition-all duration-700 ${inView?"opacity-100 translate-y-0":"opacity-0 translate-y-6"}`}>
          <div className="text-[9px] tracking-[0.4em] mb-3" style={{ color:"rgba(0,180,216,0.5)", fontFamily:"'Orbitron',monospace" }}>LAYER 02 · INTERACTIVE MISSION SIMULATION</div>
          <h2 className="text-3xl font-bold mb-3" style={{ fontFamily:"'Orbitron',monospace", color:"#cce4f7" }}>任务模拟演示系统</h2>
          <p className="text-sm" style={{ color:"#3d6e92" }}>选择作战场景，点击启动模拟，实时呈现无人机系统完整任务执行链路</p>
        </div>
        {/* Scenario selector */}
        <div className={`grid grid-cols-2 md:grid-cols-4 gap-3 mb-8 transition-all duration-700 delay-100 ${inView?"opacity-100":"opacity-0"}`}>
          {SCENARIOS.map(s => (
            <button key={s.id} onClick={() => handleSelect(s.id)} disabled={running} className="p-4 text-left transition-all duration-200"
              style={{ border:`1px solid ${selected===s.id?s.color+"60":s.color+"20"}`, background:selected===s.id?`${s.color}0c`:"rgba(6,18,31,0.6)", cursor:running?"not-allowed":"pointer", opacity:running&&selected!==s.id?0.4:1 }}>
              <div className="text-xs font-bold mb-1" style={{ fontFamily:"'Orbitron',monospace", color:selected===s.id?s.color:"#cce4f7" }}>{s.title}</div>
              <div className="text-[9px] tracking-wider" style={{ color:selected===s.id?`${s.color}99`:"#3d6e92" }}>{s.sub}</div>
              {selected===s.id && <div className="mt-2 h-px" style={{ background:s.color }} />}
            </button>
          ))}
        </div>
        {/* Main panel */}
        <div className={`grid grid-cols-1 lg:grid-cols-2 gap-4 transition-all duration-700 delay-200 ${inView?"opacity-100":"opacity-0"}`}>
          {/* Left: steps */}
          <div className="p-5" style={{ border:`1px solid ${scenario.color}20`, background:"rgba(6,18,31,0.85)" }}>
            <div className="flex items-center justify-between mb-5">
              <div>
                <div className="text-[9px] tracking-[0.3em] mb-1" style={{ color:`${scenario.color}70`, fontFamily:"'Orbitron',monospace" }}>MISSION FLOW</div>
                <div className="text-sm font-bold" style={{ color:"#cce4f7", fontFamily:"'Orbitron',monospace" }}>{scenario.title} · 任务链路</div>
              </div>
              <button onClick={runSimulation} disabled={running} className="px-5 py-2 text-[10px] font-bold tracking-wider transition-all duration-200"
                style={{ fontFamily:"'Orbitron',monospace", background:running?"rgba(0,0,0,0.3)":scenario.color, color:running?scenario.color:"#040d1a", border:`1px solid ${scenario.color}`, cursor:running?"not-allowed":"pointer", opacity:running?0.6:1 }}>
                {running ? "执行中..." : "启动模拟"}
              </button>
            </div>
            <div className="flex flex-col gap-2">
              {scenario.steps.map((step, i) => {
                const isActive = i === currentStep; const isDone = i < currentStep;
                return (
                  <div key={i} className="flex gap-3 p-3 transition-all duration-500"
                    style={{ border:`1px solid ${isActive?scenario.color+"60":isDone?scenario.color+"25":"rgba(0,180,216,0.08)"}`, background:isActive?`${scenario.color}0d`:isDone?`${scenario.color}05`:"transparent", boxShadow:isActive?`0 0 16px ${scenario.color}20`:"none" }}>
                    <div className="flex-shrink-0 w-6 h-6 flex items-center justify-center text-[9px] font-bold mt-0.5"
                      style={{ fontFamily:"'Orbitron',monospace", border:`1px solid ${isActive?scenario.color:isDone?scenario.color+"60":"rgba(0,180,216,0.2)"}`, color:isActive?scenario.color:isDone?scenario.color+"aa":"#3d6e92", background:isDone?`${scenario.color}15`:"transparent" }}>
                      {isDone ? "✓" : (i+1)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-[11px] font-bold mb-0.5" style={{ color:isActive?scenario.color:isDone?"#cce4f7":"#3d6e92" }}>
                        {step.label}
                        {isActive && <span className="ml-2 text-[8px] tracking-wider" style={{ color:scenario.color, animation:"pulse 1.4s ease-in-out infinite" }}>RUNNING</span>}
                      </div>
                      <div className="text-[10px] leading-relaxed" style={{ color:isActive||isDone?"#3d6e92":"#1e4060" }}>{step.desc}</div>
                      {(isActive||isDone) && (
                        <div className="mt-1.5 text-[9px] px-2 py-0.5 inline-block" style={{ border:`1px solid ${scenario.color}30`, color:`${scenario.color}cc`, background:`${scenario.color}08` }}>{step.data}</div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="mt-4">
              <div className="flex justify-between items-center mb-1.5">
                <span className="text-[9px]" style={{ color:"#3d6e92" }}>任务进度</span>
                <span className="text-[9px] font-bold" style={{ color:scenario.color, fontFamily:"'Orbitron',monospace" }}>{progress}%</span>
              </div>
              <div className="h-1" style={{ background:"rgba(0,0,0,0.4)" }}>
                <div className="h-full transition-all duration-700 ease-out" style={{ width:`${progress}%`, background:scenario.color, boxShadow:`0 0 8px ${scenario.color}80` }} />
              </div>
            </div>
          </div>
          {/* Right: data + log */}
          <div className="flex flex-col gap-4">
            <div className="p-5" style={{ border:"1px solid rgba(0,180,216,0.15)", background:"rgba(6,18,31,0.85)" }}>
              <div className="text-[9px] tracking-[0.3em] mb-4" style={{ color:"rgba(0,180,216,0.5)", fontFamily:"'Orbitron',monospace" }}>LIVE DATA READOUT · 实时数据面板</div>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label:"系统状态", value:running?"EXECUTING":currentStep>=scenario.steps.length-1&&currentStep>=0?"COMPLETE":"STANDBY", color:running?scenario.color:currentStep>=scenario.steps.length-1&&currentStep>=0?"#22c55e":"#3d6e92" },
                  { label:"当前步骤", value:currentStep>=0?`${currentStep+1} / ${scenario.steps.length}`:` -- / ${scenario.steps.length}`, color:"#cce4f7" },
                  { label:"作战场景", value:scenario.title, color:scenario.color },
                  { label:"AI置信度", value:running&&currentStep>=0?confidence:"--", color:"#00b4d8" },
                ].map((item,i) => (
                  <div key={i} className="p-3" style={{ border:"1px solid rgba(0,180,216,0.08)", background:"rgba(0,0,0,0.2)" }}>
                    <div className="text-[9px] mb-1" style={{ color:"#3d6e92" }}>{item.label}</div>
                    <div className="text-[11px] font-bold" style={{ color:item.color, fontFamily:"'Orbitron',monospace" }}>{item.value}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="flex-1 p-5" style={{ border:"1px solid rgba(0,180,216,0.12)", background:"rgba(4,10,20,0.9)", minHeight:"220px" }}>
              <div className="flex items-center gap-2 mb-4">
                <span className="w-1.5 h-1.5 rounded-full" style={{ background:running?"#22c55e":"#3d6e92", boxShadow:running?"0 0 6px #22c55e":"none" }} />
                <span className="text-[9px] tracking-[0.3em]" style={{ color:"rgba(0,180,216,0.4)", fontFamily:"'Orbitron',monospace" }}>SYSTEM LOG · 系统日志</span>
              </div>
              <div className="font-mono text-[10px] space-y-1 overflow-y-auto" style={{ maxHeight:"180px", color:"#3d6e92" }}>
                {logs.length===0 ? (
                  <div style={{ color:"#1e4060" }}>{">"} 等待任务启动...</div>
                ) : logs.map((log,i) => (
                  <div key={i} className="flex gap-2">
                    <span className="flex-shrink-0" style={{ color:"#1e4060" }}>{log.time}</span>
                    <span style={{ color:i===0?log.color:"#3d6e92" }}>{log.text}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─────────────── FOOTER ─────────────── */
function Footer() {
  return (
    <footer className="py-12" style={{ background:"#040d1a", borderTop:"1px solid rgba(0,180,216,0.1)" }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="text-sm font-bold tracking-widest mb-1" style={{ fontFamily:"'Orbitron',monospace", color:"#00b4d8" }}>空基尖兵</div>
            <div className="text-[10px] tracking-wider" style={{ color:"#3d6e92" }}>智能空基无人机协同体系 · 国家创新竞赛参赛项目</div>
          </div>
          <div className="flex flex-wrap gap-6">
            {[["项目类别","国家级创新竞赛"],["技术方向","低空智能系统"],["应用领域","公共安全 / 应急响应"]].map(([k,v]) => (
              <div key={k}>
                <div className="text-[9px] tracking-wider mb-0.5" style={{ color:"#1e4060" }}>{k}</div>
                <div className="text-[10px]" style={{ color:"#3d6e92" }}>{v}</div>
              </div>
            ))}
          </div>
          <div className="flex items-center gap-2 px-3 py-2 text-[9px] tracking-[0.2em]" style={{ border:"1px solid rgba(0,180,216,0.15)", color:"#3d6e92" }}>
            <span className="w-1.5 h-1.5 rounded-full" style={{ background:"#22c55e", boxShadow:"0 0 4px #22c55e" }} />
            SYSTEM OPERATIONAL
          </div>
        </div>
        <div className="mt-8 pt-6 flex items-center justify-between" style={{ borderTop:"1px solid rgba(0,180,216,0.06)" }}>
          <span className="text-[9px]" style={{ color:"#1e4060" }}>AERIAL VANGUARD SYSTEM · INTELLIGENT COORDINATION PLATFORM</span>
          <span className="text-[9px]" style={{ color:"#1e4060" }}>CONFIDENTIAL · FOR COMPETITION USE ONLY</span>
        </div>
      </div>
    </footer>
  );
}

/* ─────────────── PAGE ─────────────── */
export default function Page() {
  return (
    <main style={{ background:"#040d1a" }}>
      <SiteNav />
      <HeroSection />
      <StrategySection />
      <ProblemSection />
      <ArchitectureSection />
      <TechnologySection />
      <SimulationSection />
      <Footer />
    </main>
  );
}
